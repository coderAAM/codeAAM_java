 import java.util.Scanner;
 
 class AAM{
    public static boolean vaildateEmail (String email){
        return email.contains("@") && email.contains(".");
    }
    public static boolean vaildatePassword (String password){
        if (password.length()<8){
            return false;
        }
        
        boolean hasUpperCase  = false;
        boolean hasLowerCase = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;
        
        for (char ch: password.toCharArray()){
            if(Character.isUpperCase(ch)) hasUpperCase = true;
            else if (Character.isLowerCase(ch)) hasLowerCase = true;
            else if (Character.isLowerCase(ch)) hasLowerCase = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else if (Character.isLetterOrDigit(ch)) hasSpecialChar = true;
        }  
        return hasUpperCase && hasLowerCase && hasDigit && hasSpecialChar;
        }
        public static void main (String[] args) {
          Scanner sc = new Scanner(System.in);
            System.out.println("Login Form");
        
        
        System.out.println("Enter your first name:");
        String firstName = sc.nextLine();
        
        
        System.out.println("Enter your last name:");
        String lastName = sc.nextLine();
        
       
        System.out.println("Enter your age:");
        int age = sc.nextInt();
        sc.nextLine(); 
        
        if (age < 18) {
            System.out.println("You are not eligible to use this form.");
            sc.close();
            return;
        }
        System.out.println("Enter your email");
        String email = sc.nextLine();
        if (!vaildateEmail(email)){
            System.out.println("Password must be at least 8 characters long and include uppercase, lowercase, digit, and special character.");
            sc.close();
            return;
        } 
        System.out.println("Enter your Password:");
        String Password = sc.nextLine();
        if(!vaildatePassword(Password)){
        System.out.println("Password must be at least 8 characters long and include uppercase, lowercase, digit, and special character.");
        sc.close();
        return;
        }
        System.out.println("Form submitted successfully!");
        sc.close();
        }
}