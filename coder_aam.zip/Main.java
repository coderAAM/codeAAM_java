import java.util.Scanner;

class Main {
    
    // Method to validate email
    public static boolean validateEmail(String email) {
        return email.contains("@") && email.contains(".");
    }
    
    // Method to validate password
    public static boolean validatePassword(String password) {
        if (password.length() < 8) {
            return false; // Password should be at least 8 characters long
        }
        
        boolean hasUpperCase = false;
        boolean hasLowerCase = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;
        
        for (char ch : password.toCharArray()) {
            if (Character.isUpperCase(ch)) hasUpperCase = true;
            else if (Character.isLowerCase(ch)) hasLowerCase = true;
            else if (Character.isDigit(ch)) hasDigit = true;
            else if (!Character.isLetterOrDigit(ch)) hasSpecialChar = true;
        }
        
        // Password is valid only if all conditions are met
        return hasUpperCase && hasLowerCase && hasDigit && hasSpecialChar;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Login Form");
        
        // User's first name
        System.out.println("Enter your first name:");
        String firstName = sc.nextLine();
        
        // User's last name
        System.out.println("Enter your last name:");
        String lastName = sc.nextLine();
        
        // User's age
        System.out.println("Enter your age:");
        int age = sc.nextInt();
        sc.nextLine(); // Consume the leftover newline character
        
        if (age < 18) {
            System.out.println("You are not eligible to use this form.");
            sc.close();
            return;
        }
        
        // Enter and validate email
        System.out.println("Enter your Email:");
        String email = sc.nextLine();
        if (!validateEmail(email)) {
            System.out.println("Invalid email format. Please try again.");
            sc.close();
            return;
        }
        
        // Enter and validate password
        System.out.println("Enter your password:");
        String password = sc.nextLine();
        if (!validatePassword(password)) {
            System.out.println("Password must be at least 8 characters long and include uppercase, lowercase, digit, and special character.");
            sc.close();
            return;
        }
        
        System.out.println("Form submitted successfully!");
        
        sc.close();
    }
}
